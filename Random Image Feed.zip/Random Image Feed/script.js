//calling dom elements to work with 
const imgsContainer = document.querySelector('.container')
const imgsNum = document.querySelector('.imgs-num');
const clearBtn = document.querySelector('.clear')
let number_Of_IMGS 


/**event Listeners */
clearBtn.addEventListener('click',()=>{
     number_Of_IMGS=0;
     generateRandomImages(number_Of_IMGS)
    //or
    imgsContainer.innerHTML='';
})
imgsNum.addEventListener('input',()=>{

    const inputValue = +imgsNum.value;
 
    setTimeout(()=>{   imgsNum.value='';},1000)
    number_Of_IMGS = inputValue
    generateRandomImages(number_Of_IMGS)

  
}) 

//fucntions to generate random images and numbers 
function generateRandomImages(imgsNumber){
    imgsContainer.innerHTML=''
    for(let i = 0;i<imgsNumber;i++){
        const div = document.createElement('div');
        div.classList.add('test');
        div.innerHTML=`
        <img src="https://source.unsplash.com/random/${generateSize()}" class="imgs">
         `
        imgsContainer.appendChild(div);
    }
}
function generateSize(){
    return `${generateNum()}x${generateNum()}`
}
function generateNum(){

    return Math.floor(Math.random()*10)+300
}