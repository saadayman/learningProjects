  const inputEl = document.getElementById('search');
  const form = document.getElementById('form');
  const USER_API_URL = 'https://api.github.com/users/';
  const cardContainer = document.getElementById('card-container');
  const userRepos =[];
   async function getUsers(username){
    try{

      const {data} = await axios(`${USER_API_URL}${username}`)
 
      console.log(data);
      addUserToDom(data);

    } catch(err){
      if(err.response.status == 404){
        console.log('hello');
      cardContainer.innerHTML=`<div class="error">There is no user with this name</div>`
    }
    }
   
    // .then(data=>console.log(data.data))
    // .catch(err=> cardContainer.innerHTML=` <div class="error">${err}</div>`)
 }

 async function getRepos(username){
   try{
     const {data} = await axios(`${USER_API_URL}${username}/repos`)
    addRepos(data);
   } catch(err){

    console.log(err);
   }
 }

 function addUserToDom(userInfo){
   cardContainer.innerHTML='';
  const userEl = document.createElement('div');
  userEl.classList.add('card-info');
  userEl.innerHTML = `
  <div class="user-img">
  <img src=${userInfo.avatar_url} alt=${userInfo.avatar_url}>
  </div>
  <div class="user-info">
  <div>  <h1 class="username">${userInfo.name}</h1>
  <p class="user-bio">${userInfo.bio === null ? ' '  : userInfo.bio}</p>
</div>
  <div class="account-info">
      <div>${userInfo.followers} followers</div>
      <div>${userInfo.following} following</div>
      <div>${userInfo.public_repos} repos</div>
  </div>



<div class="projects">

</div>


</div> 
  
  `
  
cardContainer.appendChild(userEl);
 }
 function addRepos(data){
  const repos = document.querySelector('.card-info').querySelector('.projects');
  console.log(data);
  data
  .slice(0,10)
  .forEach(data=>{
    const project =  document.createElement('div');
    project.classList.add('project');
    project.innerHTML=data.name;
    repos.appendChild(project);
  })

}

  //add Event Listener
  form.addEventListener('submit',(e)=>{
    e.preventDefault();
   const userName =  inputEl.value.trim().toLowerCase();
   console.log(userName);
    if(userName){
   getUsers(userName);
   getRepos(userName);
   inputEl.value = '';
    }
    else{
      cardContainer.innerHTML=`<div class="error">Please Enter  A Name to search for</div>`
    }

  })