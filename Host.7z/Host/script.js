const loading = document.querySelector('.loading');
setTimeout(()=>{

loading.remove();
},3000);
const mobileNav= document.querySelector('.mobile');
const toggleBtn = document.querySelector('.toggle-btn');
toggleBtn.addEventListener('click',()=>{
mobileNav.classList.toggle('toggle');

})