<!DOCTYPE html>
<html lang="en">

  


<head >
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="favicon.ico">
<title>
  حساب المعدل المتوقع 
</title>
<link rel="stylesheet" href="Gstyle.css">
 <script src="https://kit.fontawesome.com/fa16d54c64.js" crossorigin="anonymous"></script>
 <script defer src="script.js"></script>
</head>



<?php error_reporting(0); ?>

<body>
    <nav>
    <button class="toggle-btn"><i class="fa fa-bars "></i></button>
    <ul>
       
       <li><a href="https://elcom-hu.com/main/" aria-current="page">الصفحة الرئيسية</a></li>
       <li><a href="_#" aria-current="page" class="active">حساب المعدل</a></li>
       <li><a href="https://elcom-hu.com/main/%d8%a8%d8%b1%d8%a7%d9%85%d8%ac-%d9%87%d9%86%d8%af%d8%b3%d9%8a%d8%a9/">برامج هندسية</a></li>
       <li><a href="https://elcom-hu.com/main/%d8%a7%d9%84%d8%af%d8%b9%d9%85-%d8%a7%d9%84%d9%81%d9%86%d9%8a/">الدعم الفني</a></li>
       <li><a href="https://elcom-hu.com/main/elcom-%d8%b9%d8%a7%d8%a6%d9%84%d8%a9/">ElCoM عائلة</a></li>
   </ul>
   <a href="https://elcom-hu.com/main/"><img src="https://elcom-hu.com/wpadmin/wp-content/uploads/2021/03/ElCoM-new-logo.png" alt="elcom-logo" class="logo-img"></a>
</nav>
<div class="mobile">
<ul>
       
       <li><a href="https://elcom-hu.com/main/" aria-current="page">الصفحة الرئيسية</a></li>
       <li><a href="#" target="#" aria-current="page" class="active">حساب المعدل</a></li>
       <li><a href="https://elcom-hu.com/main/%d8%a8%d8%b1%d8%a7%d9%85%d8%ac-%d9%87%d9%86%d8%af%d8%b3%d9%8a%d8%a9/">برامج هندسية</a></li>
       <li><a href="https://elcom-hu.com/main/%d8%a7%d9%84%d8%af%d8%b9%d9%85-%d8%a7%d9%84%d9%81%d9%86%d9%8a/">الدعم الفني</a></li>
       <li><a href="https://elcom-hu.com/main/elcom-%d8%b9%d8%a7%d8%a6%d9%84%d8%a9/">ElCoM عائلة</a></li>
       
   </ul>
</div>

<section class="gpa-img">
</section>

<h1 class="gpa-cal">حساب المعدل</h1>
         
      
<div id="wrapper">


	<div id="content-top"><!-- nothing to see here --></div>

	<div id="content-wrapper">
	<div id="sub-header">

	





			




			





			</div>
				

 <!-- Begin BidVertiser code -->

 <SCRIPT data-cfasync="false" SRC="//bdv.bidvertiser.com/BidVertiser.dbm?pid=808272&bid=1942310" TYPE="text/javascript"></SCRIPT>
<!-- End BidVertiser code --> 





<!-- Histats.com  START (hidden counter)-->







<!-- Histats.com  END  -->










	





	<div id="content_wrapper">





		<div id="main">





			




              





            





            <div id="sidebar">


	

	

</div>




            





            <div class="the-single-post " > 









                <div class="entry" style="height: 500px ">
                    
                    <!DOCTYPE html>

                    <!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html  xmlns="http://www.w3.org/1999/xhtml" xmlns:fb="http://ogp.me/ns/fb#"  dir="rtl" >
    <head>

        
        
        <title>حساب المعدل المتوقع</title>
    <link rel="shortcut icon" href="http://www.elcom-hu.com/favicon1.ico">
    </head>
    
        
        <?php
$file = "counts.html";

    if ( is_file( $file )==false )  {touch($file);$open = fopen($file, "w");fwrite($open, "0");fclose($open);}

//read counts
$open = fopen($file, "r");
$count = fread($open, filesize($file));
fclose($open);

//if cookie isn't already set,then increase counts by one + save ip, and set a cookie to pc...
$cookie_namee='mycounterr-456';
    if (!isset($_COOKIE[$cookie_namee])) {
    $open = fopen($file, "w");
    $count++;
    fwrite($open, $count);
    fclose($open);
    setcookie($cookie_namee,"Checked",time()+111400);
    }

//uncomment the below line to see the visits number on page
//echo $count;
?>

       
  
        <form action="Grade.php" method="POST" >
            
    
<script type="text/javascript">
    google_ad_client = "ca-pub-5446432160501692";
    google_ad_slot = "1017146354";
    google_ad_width = 728;
    google_ad_height = 90;
</script>
<!-- oo -->
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
	
	
	
	
        <?php
          

   $m1= $_POST['m1'];
   $m2= $_POST['m2'];      
   $m3= $_POST['m3'];      
   $m4= $_POST['m4'];      
   $m5= $_POST['m5'];      
   $m6= $_POST['m6'];      
   $m7= $_POST['m7'];      
   $m8= $_POST['m8'];      
   $m9= $_POST['m9'];      
   $m10= $_POST['m10'];  
   
   $o1= $_POST['o1'];  
   $o2= $_POST['o2'];      
   $o3= $_POST['o3'];      
   $o4= $_POST['o4'];      
   $o5= $_POST['o5'];      
   $o6= $_POST['o6'];      
   $o7= $_POST['o7'];      
   $o8= $_POST['o8'];      
   $o9= $_POST['o9'];      
   $o10= $_POST['o10'];      
   
   $h1= $_POST['h1'];      
   $h2= $_POST['h2'];      
   $h3= $_POST['h3'];      
   $h4= $_POST['h4'];      
   $h5= $_POST['h5'];      
   $h6= $_POST['h6'];      
   $h7= $_POST['h7'];      
   $h8= $_POST['h8'];      
   $h9= $_POST['h9'];      
   $h10= $_POST['h10'];
   
         if($m1=="0"){}else{$h1=($h1*$m1)/$m1;}
         if($m2=="0"){}else{$h2=($h2*$m2)/$m2;}
         if($m3=="0"){}else{$h3=($h3*$m3)/$m3;}
         if($m4=="0"){}else{$h4=($h4*$m4)/$m4;}
         if($m5=="0"){}else{$h5=($h5*$m5)/$m5;}
         if($m6=="0"){}else{$h6=($h6*$m6)/$m6;}
         if($m7=="0"){}else{$h7=($h7*$m7)/$m7;}
         if($m8=="0"){}else{$h8=($h8*$m8)/$m8;}
         if($m9=="0"){}else{$h9=($h9*$m9)/$m9;}
         if($m10=="0"){}else{$h10=($h10*$m10)/$m10;}

   $oldG= $_POST['oldG'];  
   $oldH= $_POST['oldH']; 
   
   $semsopNEW= $m1*$h1
        +$m2*$h2
        +$m3*$h3   
        +$m4*$h4
        +$m5*$h5   
        +$m6*$h6
        +$m7*$h7   
        +$m8*$h8
        +$m9*$h9
        +$m10*$h10  ; 
   
   
      if($o1 =='' || $o1 =="a"){}else{$hO1=$h1;} 
      if($o2 =='' || $o2 =="اختر"){}else{$hO2=$h2;}
      if($o3 =='' || $o3 =="اختر"){}else{$hO3=$h3;}
      if($o4 =='' || $o4 =="اختر"){}else{$hO4=$h4;}
      if($o5 =='' || $o5 =="اختر"){}else{$hO5=$h5;}
      if($o6 =='' || $o6 =="اختر"){}else{$hO6=$h6;}
      if($o7 =='' || $o7 =="اختر"){}else{$hO7=$h7;}
      if($o8 =='' || $o8 =="اختر"){}else{$hO8=$h8;}
      if($o9 =='' || $o9 =="اختر"){}else{$hO9=$h9;}
      if($o10 =='' || $o10 =="اختر"){}else{$hO10=$h10;}

      
      $semsopOLD= $o1*$hO1
        +$o2*$hO2
        +$o3*$hO3   
        +$o4*$hO4
        +$o5*$hO5   
        +$o6*$hO6
        +$o7*$hO7   
        +$o8*$hO8
        +$o9*$hO9
        +$o10*$hO10  ; 
    
      
   
       
     $semH = $h1 + $h2 + $h3 + $h4 + $h5 + $h6 + $h7 + $h8 + $h9  + $h10 ;
  
     $semHO = $hO1 + $hO2 + $hO3 + $hO4 + $hO5 + $hO6 + $hO7 + $hO8 + $hO9  + $hO10 ;

     $semG = $semsopNEW / $semH;
   
     $totalH= $oldH+$semH-$semHO;
           
     $totalG =  (($oldG*$oldH)- ($semsopOLD)+($semH*$semG))/($totalH );
   
     
     
   if ($semG > 4  || $totalG >4 || $totalG<0  || $semG <0 )
   {
       
               echo "<script type='text/javascript'>alert('الرجاء التأكد من المدخلات')</script>";
               header("Refresh:0");
               


   }
   else{
   if ($oldG > 4 )
   {
           echo "<script type='text/javascript'>alert('ادخل المعدل التراكمي السابق  بشكل صحيح')</script>";
   }
 
   } 
   
 //  if ($semG <2 && $semG >0 )
 ////  {
  ///      echo "<script type='text/javascript'>alert('انذار اكاديمي !!')</script>";
   //}
  //  if ($semG >= 3.5  )
   //{
    //    echo "<script type='text/javascript'>alert('لوحة الشرف :)')</script>";
 //  }

 
        ?>

            
    <div class="border">

            <table class="imagetable" style="position: relative;left: -113px;top: 37px;"  >
           
                  
                
                
            </div>
                
                </th>
                <th>عدد<br>ساعات<br>المادة</th>
                <th>العلامة<br>الجديدة</th>
                <th>العلامة<br>السابقة</th>
                
            </tr>
            
            <tr>
                
             
                 <td> <input  type="text" name="h1" value="<?php if(isset($_POST['h1'])){echo htmlentities($_POST['h1']);}?>" style="width: 35pt;text-align: center; "    ></td>
                 <td>  <select  name="m1" >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['m1'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m1'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m1'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m1'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m1'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m1'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m1'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m1'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m1'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m1'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m1'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m1'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m1'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select>  </td>
                

                 <td>
                     <input type="checkbox" name="s1" id="s1" <?php if(isset($_POST['s1'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o1').disabled=!this.checked;  "
 >

        
                     
                     <select  name="o1" id="o1" <?php   if(isset($_POST['s1'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="a" <?php if ($_POST['o1'] == '0') echo 'selected="selected"'; ?>>اختر</option>true;}
            <option value="4" <?php if ($_POST['o1'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o1'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o1'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o1'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o1'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o1'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o1'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o1'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o1'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o1'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o1'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o1'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                 </td>
            </tr>
            <tr>
                
                <td> <input  type="text" name="h2" value="<?php if(isset($_POST['h2'])){echo htmlentities($_POST['h2']);}?>" style="width: 35pt;text-align: center; "    ></td>
                   <td>
                       
                       
                       
                       <select  name="m2" >  
            <option value="اختر" <?php if ($_POST['m2'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m2'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m2'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m2'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m2'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m2'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m2'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m2'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m2'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m2'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m2'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m2'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m2'] == '0') echo 'selected="selected"'; ?>>F</option>   
         </select>  </td>
                   
                   <td>
                       
                                               <input type="checkbox" name="s2" id="s2" <?php if(isset($_POST['s2'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o2').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o2" id="o2" <?php   if(isset($_POST['s2'])){}else { echo "disabled='disabled'";} ?>   >  
 
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o2'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o2'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o2'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o2'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o2'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o2'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o2'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o2'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o2'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o2'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o2'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o2'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o2'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
                
                
            </tr>
            <tr>
           
                <td> <input  type="text" name="h3" value="<?php if(isset($_POST['h3'])){echo htmlentities($_POST['h3']);}?>" style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m3" >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['m3'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m3'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m3'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m3'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m3'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m3'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m3'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m3'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m3'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m3'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m3'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m3'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m3'] == '0') echo 'selected="selected"'; ?>>F</option>   
           </select>  </td>
                
                         <td>
                       
                                             <input type="checkbox" name="s3" id="s3" <?php if(isset($_POST['s3'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o3').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o3" id="o3" <?php   if(isset($_POST['s3'])){}else { echo "disabled='disabled'";} ?>   >  
  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o3'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o3'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o3'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o3'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o3'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o3'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o3'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o3'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o3'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o3'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o3'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o3'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o3'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
            </tr>
            <tr>
             
                <td> <input  type="text" name="h4" value="<?php if(isset($_POST['h4'])){echo htmlentities($_POST['h4']);}?>" style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m4" >  
            <option value="اختر" <?php if ($_POST['m4'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m4'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m4'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m4'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m4'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m4'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m4'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m4'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m4'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m4'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m4'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m4'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m4'] == '0') echo 'selected="selected"'; ?>>F</option>   
             </select>  </td>
                   
                            <td>
                       
                     <input type="checkbox" name="s4" id="s4" <?php if(isset($_POST['s4'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o4').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o4" id="o4" <?php   if(isset($_POST['s4'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o4'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o4'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o4'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o4'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o4'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o4'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o4'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o4'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o4'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o4'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o4'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o4'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o4'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
                
                
            </tr>
            <tr>
               
                <td> <input  type="text" name="h5" value="<?php if(isset($_POST['h5'])){echo htmlentities($_POST['h5']);}?>" style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m5" >  
            <!--Call run() function-->
          <option value="اختر" <?php if ($_POST['m5'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m5'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m5'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m5'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m5'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m5'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m5'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m5'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m5'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m5'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m5'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m5'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m5'] == '0') echo 'selected="selected"'; ?>>F</option>   
            </select>  </td>
                
                         <td>
                       
                     <input type="checkbox" name="s5" id="s5" <?php if(isset($_POST['s5'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o5').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o5" id="o5" <?php   if(isset($_POST['s5'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o5'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o5'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o5'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o5'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o5'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o5'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o5'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o5'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o5'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o5'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o5'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o5'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o5'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
                   
            </tr>
            
            <tr>
            
                <td> <input  type="text" name="h6" value="<?php if(isset($_POST['h6'])){echo htmlentities($_POST['h6']);}?>" style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m6" >  
            <!--Call run() function-->
          <option value="اختر" <?php if ($_POST['m6'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m6'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m6'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m6'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m6'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m6'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m6'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m6'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m6'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m6'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m6'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m6'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m6'] == '0') echo 'selected="selected"'; ?>>F</option>   
             </select>  </td>
                
                         <td>
                       
                     <input type="checkbox" name="s6" id="s6" <?php if(isset($_POST['s6'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o6').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o6" id="o6" <?php   if(isset($_POST['s6'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o6'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o6'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o6'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o6'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o6'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o6'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o6'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o6'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o6'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o6'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o6'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o6'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o6'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
            </tr>
            <tr>
               
                <td> <input  type="text" name="h7" value="<?php if(isset($_POST['h7'])){echo htmlentities($_POST['h7']);}?>" style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m7" >  
            <!--Call run() function-->
             <option value="اختر" <?php if ($_POST['m7'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m7'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m7'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m7'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m7'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m7'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m7'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m7'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m7'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m7'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m7'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m7'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m7'] == '0') echo 'selected="selected"'; ?>>F</option>   
               </select>  </td>
                  <td>
                       
                     <input type="checkbox" name="s7" id="s7" <?php if(isset($_POST['s7'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o7').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o7" id="o7" <?php   if(isset($_POST['s7'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o7'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o7'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o7'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o7'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o7'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o7'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o7'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o7'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o7'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o7'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o7'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o7'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o7'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>       
                
            </tr>
            <tr>
                
                <td> <input  type="text" name="h8" value="<?php if(isset($_POST['h8'])){echo htmlentities($_POST['h8']);}?>" style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m8" >  
              <option value="اختر" <?php if ($_POST['m8'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m8'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m8'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m8'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m8'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m8'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m8'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m8'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m8'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m8'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m8'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m8'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m8'] == '0') echo 'selected="selected"'; ?>>F</option>   
              </select>  </td>
                
                         <td>
                       
                     <input type="checkbox" name="s8" id="s8" <?php if(isset($_POST['s8'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o8').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o8" id="o8" <?php   if(isset($_POST['s8'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o8'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o8'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o8'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o8'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o8'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o8'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o8'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o8'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o8'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o8'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o8'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o8'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o8'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
            </tr>
            
            
            
            <tr>
               
                <td> <input  type="text" name="h9" value="<?php if(isset($_POST['h9'])){echo htmlentities($_POST['h9']);}?>"  style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m9" >  
            <!--Call run() function-->
              <option value="اختر" <?php if ($_POST['m8'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m8'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m8'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m8'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m8'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m8'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m8'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m8'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m8'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m8'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m8'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m8'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m8'] == '0') echo 'selected="selected"'; ?>>F</option>   
          </select>  </td>
                         <td>
                       
                     <input type="checkbox" name="s9" id="s9" <?php if(isset($_POST['s9'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o9').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o9" id="o9" <?php   if(isset($_POST['s9'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o9'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o9'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o9'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o9'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o9'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o9'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o9'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o9'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o9'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o9'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o9'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o9'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o9'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
                
            </tr>
            <tr>

                <td> <input  type="text" name="h10" value="<?php if(isset($_POST['h10'])){echo htmlentities($_POST['h10']);}?>" style="width: 35pt;text-align: center;"    ></td>
                   <td>  <select  name="m10" >  
            <!--Call run() function-->
         <option value="اختر" <?php if ($_POST['m10'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['m10'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['m10'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['m10'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['m10'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['m10'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['m10'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['m10'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['m10'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['m10'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['m10'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['m10'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['m10'] == '0') echo 'selected="selected"'; ?>>F</option>   
            </select>  </td>
                
                         <td>
                       
                     <input type="checkbox" name="s10" id="s10" <?php if(isset($_POST['s10'])) echo "checked='checked'"; ?>  onclick="document.getElementById('o10').disabled=!this.checked;  "
 >
                     
                     
                     <select  name="o10" id="o10" <?php   if(isset($_POST['s10'])){}else { echo "disabled='disabled'";} ?>   >  
            <!--Call run() function-->
            <option value="اختر" <?php if ($_POST['o10'] == '0') echo 'selected="selected"'; ?>>اختر</option>
            <option value="4" <?php if ($_POST['o10'] == '4') echo 'selected="selected"'; ?>>A+</option>
            <option value="3.75"<?php if ($_POST['o10'] == '3.75') echo 'selected="selected"'; ?>>A</option>
            <option value="3.5"<?php if ($_POST['o10'] == '3.5') echo 'selected="selected"'; ?>>A-</option>
            <option value="3.25"<?php if ($_POST['o10'] == '3.25') echo 'selected="selected"'; ?>>B+</option> 
            <option value="3"<?php if ($_POST['o10'] == '3') echo 'selected="selected"'; ?>>B</option>   
            <option value="2.75"<?php if ($_POST['o10'] == '2.75') echo 'selected="selected"'; ?> >B-</option>   
            <option value="2.5"<?php if ($_POST['o10'] == '2.5') echo 'selected="selected"'; ?>>C+</option>   
            <option value="2.25"<?php if ($_POST['o10'] == '2.25') echo 'selected="selected"'; ?>>C</option>   
            <option value="2"<?php if ($_POST['o10'] == '2') echo 'selected="selected"'; ?>>C-</option>   
            <option value="1.75"<?php if ($_POST['o10'] == '1.75') echo 'selected="selected"'; ?>>D+</option>   
            <option value="1.5"<?php if ($_POST['o10'] == '1.5') echo 'selected="selected"'; ?>>D</option>   
            <option value="0"<?php if ($_POST['o10'] == '0') echo 'selected="selected"'; ?>>F</option>   
        </select> 
                   </td>
            </tr>
            
            
        </table>
            
     <table class="imagetable" style="position: relative;left: -384px;top: -417px;">
                <tr>
                    <td>المعدل التراكمي السابق</td>
                    <td>
                    
                        <input type="text" name="oldG" value="<?php if(isset($_POST['oldG'])){echo htmlentities($_POST['oldG']);}?>" style="width: 35pt;text-align: center" ></td>

                    <td>الساعات المقطوعة السابقة</td>
                    <td><input type="text" name="oldH" value="<?php if(isset($_POST['oldH'])){echo htmlentities($_POST['oldH']);}?>" style="width: 35pt;text-align: center;"></td>
                </tr>
                <tr>
        
                      
                </tr>
            </table>
            
                   <table class="imagetable" style="position: relative;left: -384px;top: -389px;">
                <tr>
                    <th>ساعات الفصل</th>
                    <th> <input type="text" value="<?php echo $semH; ?>" style="width: 35pt;text-align: center;" readonly="readonly" >   </th>
             
                    <th>المعدل الفصلي المتوقع:</th>
                    <th><input type="text" value="<?php  echo round($semG, 2); ?>" style="width: 35pt;text-align: center;" readonly="readonly" </th>
             
                </tr>
                
                
                <tr>
            </tr>
                <tr>
                    <th>التقدير:</th>
                    <th> <input  type="text" style="width: 35pt;text-align: center;" readonly="readonly"  value="<?php   if ($totalG >=3.5) {
       echo "ممتاز";
    
} else {
    if ($totalG>=3) {
        echo "جيد جداً";
        
    } else {
        if ($totalG >=2.5) {
            echo "جيد";
            
        }  else {
            if ($totalG >=2) {
                echo "مقبول";
                
            }  else {
                if ($totalG >0) {
                    
                 echo "ضعيف";    
                }
                   
            }
        }
    }
}    ?>"</th>
                    <th>لوحة الشرف/انذار</th>
                    <th><input  type="text"   style="width: 35pt"
                               
                               
                               readonly="readonly" ></th>
                    
                </tr>
                <tr>
                
                </tr>
                     <tr>
                    <th>الساعات الداخلة في<br>حساب المعدل التراكمي</th>
                    <th> <input type="text" value="<?php echo "$totalH";?>" style="width: 35pt;text-align: center;" readonly="readonly" >   </th>
                        <th>المعدل التراكمي المتوقع:</th>
                    <th> <input type="text" title="± 0.01" value="<?php echo round($totalG, 2); ?>" style="width: 35pt;text-align: center;" readonly="readonly" >   </th>
             
                </tr>
            </table>

                <input id="round" type="submit" name="cal"   title="احسب" value="احسب" style="position: relative;left: -720px;top: -345px;">
</div>


<!-- hitwebcounter Code START -->


  
<!-- Histats.com  START (hidden counter)-->
<script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script>


<!-- Histats.com  END  -->

<!-- Histats.com  START (hidden counter)-->
<script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script>


<!-- Histats.com  END  -->
            
            </form>



                </div>

















            </div> <!-- the_post -->











   <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- oo -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-5446432160501692"
     data-ad-slot="1017146354"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>         	

















		</div> <!-- main -->





	</div> <!-- content_wrapper -->





	<div id="content_bottom"><!-- nothing to see here --></div>











</div> <!-- content_wrapper -->





	<div id="content-bottom"><!-- nothing to see here --></div>





	





	<div id="footer" 
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- oo -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-5446432160501692"
     data-ad-slot="1017146354"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>





	








	</div>





        





</div> 
<div class="notes">
<p>  :ملاحظة لحساب المعدل التراكمي بنظام ناجح راسب
        
</p>
<br>
<p>اذا كنت قد احتسبت مواد على نظام (ناجح/راسب) في الفصول السابقة، فعليك الآن جمع الساعات المحسوبة في المعدل فقط وليس عدد الساعات الكلية المقطوعة</p>
</div>
<div class="loading"></div><!-- end wrapper -->






















<!--[if IE 6]>





<script type="text/javascript"> 





	/*Load jQuery if not already loaded*/ if(typeof jQuery == 'undefined'){ document.write("<script type=\"text/javascript\"   src=\"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js\"></"+"script>"); var __noconflict = true; } 





	var IE6UPDATE_OPTIONS = {





		icons_path: "http://static.ie6update.com/hosted/ie6update/images/"





	}





</script>





<script type="text/javascript" src="http://static.ie6update.com/hosted/ie6update/ie6update.js"></script>





<![endif]-->
















</body>
</html>