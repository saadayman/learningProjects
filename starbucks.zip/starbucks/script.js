let thumb1 =document.querySelector('.img1');
let thumb2=document.querySelector('.img2');
let thumb3 =document.querySelector('.img3');

thumb1.addEventListener('click',shapeclr);
thumb2.addEventListener('click',shapeclr2);
thumb3.addEventListener('click',shapeclr3);
function shapeclr(e){
    let img= document.querySelector('.image');
    img.setAttribute("src","images/img1.png");
    let div = document.querySelector('.shape');
    
    div.style.background="linear-gradient(45deg, #000000f2, #00800087)";
    img.classList.remove('img');
}
function shapeclr2(f){
    let img= document.querySelector('.image');
    img.setAttribute("src","images/img2.png")
    img.classList.add('img');
     let div = document.querySelector('.shape');
    
    div.style.background="linear-gradient(45deg,white, #f098a8)";
    
}
function shapeclr3(s){
    
    let img= document.querySelector('.image');
    img.setAttribute("src","images/img3.png");
    let div = document.querySelector('.shape');
  
    div.style.background="linear-gradient(45deg, pink, #bc41bcd9)";
    img.classList.remove('img');
}