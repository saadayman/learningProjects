const toggle = document.querySelector('.open-btn')
const closetoggle = document.querySelector('.close-btn')
const body = document.body
toggle.addEventListener('click',()=>{
    body.querySelectorAll('.nav').forEach(nav=>nav.classList.add('visible'))
})

closetoggle.addEventListener('click',()=>{
    body.querySelectorAll('.nav').forEach(nav=>nav.classList.remove('visible'))
})

